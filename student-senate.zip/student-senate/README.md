# student-senate

https://slack-files.com/T5FE9GGDR-F5W72SJKS-e91318c448

