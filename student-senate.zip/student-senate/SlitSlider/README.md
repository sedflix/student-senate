
SlitSlider
=========

A responsive slideshow with a twist: the idea is to slice open the current slide when navigating to the next or previous one. Using jQuery and CSS animations we can create unique slide transitions for the content elements.

[article on Codrops](http://tympanus.net/codrops/2012/06/05/fullscreen-slit-slider-with-jquery-and-css3/)

[demo](http://tympanus.net/Tutorials/FullscreenSlitSlider/)

Licensed under the MIT License